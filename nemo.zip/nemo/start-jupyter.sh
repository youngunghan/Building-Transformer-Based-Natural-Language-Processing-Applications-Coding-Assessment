#!/bin/bash
jupyter lab --no-browser --allow-root --ip=0.0.0.0